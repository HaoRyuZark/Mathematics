public final class Euclidean {

    public static int greatestCommonDivisor(int n, int m) {
        if (n == 0) {
            return Math.abs(m);
        }

        while (m != 0) {
            final int r = n % m;
            n = m;
            m = r;
        }

        return Math.abs(n);
    }

    private Euclidean() {
    }

}
