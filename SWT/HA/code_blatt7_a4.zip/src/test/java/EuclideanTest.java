import org.junit.jupiter.api.Test;

public class EuclideanTest {
    @Test
    void testGreatestCommonDivisor() {

    }
}
